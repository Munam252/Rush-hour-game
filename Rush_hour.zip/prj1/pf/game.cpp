//============================================================================
// Name        : .cpp
// Author      : FAST CS Department
// Version     :
// Copyright   : (c) Reserved
// Description : Basic 2D game of Rush Hour...
//============================================================================

#ifndef RushHour_CPP_
#define RushHour_CPP_
#include "util.h"
#include <iostream>
#include <cstdlib>
#include <ctime>
#include<string>
#include<cmath> // for basic math functions such as cos, sin, sqrt
#include<string>
using namespace std;

// seed the random numbers generator by current time (see the documentation of srand for further help)...

/* Function sets canvas size (drawing area) in pixels...
 *  that is what dimensions (x and y) your game will have
 *  Note that the bottom-left coordinate has value (0,0) and top-right coordinate has value (width-1,height-1)
 * */
 


void SetCanvasSize(int width, int height) {
	glMatrixMode (GL_PROJECTION);
	glLoadIdentity();
	glOrtho(0, width, 0, height, -1, 1); // set the screen size to given width and height.
	glMatrixMode (GL_MODELVIEW);
	glLoadIdentity();
}


int xI = 7, yI = 808, size = 40;

void drawCar() {

    
     srand (time(0));
     for (int i = 0; i < 840; i++){
     int Color = rand() % 2;
     if(Color % 2 == 0){
     DrawSquare(xI, yI, 35, colors[YELLOW]);
     break;}
     }
     
     //DrawSquare(xI, yI, 35, colors[YELLOW]);
     DrawCircle(xI, yI, 7 , colors[BLACK]);
     DrawCircle(xI + 34, yI , 7 , colors[BLACK]);
     
     
     glutPostRedisplay();
    
}
     


bool flag = true;
void moveCar() {
	
	if (xI > 10 && flag) {
		xI -= 10;
		cout << "going left";
		if(xI < 100)
			
			flag = false;

	}
	else if (xI < 1010 && !flag) {
		cout << "go right";
		xI += 10;
		if (xI > 900)
			flag = true;
	}
	

	
}




void Drawing_roads(){


        int row_1 = 5, l = 600;
	for (int i=0; i<l; i++)//Using for loop to print 1st row of road.
	{
	while (row_1 <= 840)
	 {
		DrawSquare(row_1,805,40, colors[WHITE]);
		row_1 = row_1 + 42;
		row_1++;
	 }
	}
	
	int row_2 = 5;
	for (int i=0; i<l; i++)//Using for loop to print 2nd row of road.
	{
	while (row_2 <= 840)
	 {
		DrawSquare(row_2,763,40, colors[WHITE]);
		row_2 = row_2 + 42;
		row_2++;
	 }
	}
	
	int row_3 = 5;
	for (int i=0; i<l; i++)//Using for loop to print 3rd row of road.
	{
	while (row_3 <= 840)
	 {
		DrawSquare(row_3,721,40, colors[WHITE]);
		row_3 = row_3 + 42;
		row_3++;
	 }
	}
	
	int row_4 = 5;
	for (int i=0; i<l; i++)//Using for loop to print 4th row of road.
	{
	while (row_4 <= 840)
	 {
		DrawSquare(row_4,679,40, colors[WHITE]);
		row_4 = row_4 + 42;
		row_4++;
	 }
	}
	
	int row_5 = 5;
	for (int i=0; i<l; i++)//Using for loop to print 5th row of road.
	{
	while (row_5 <= 840)
	 {
		DrawSquare(row_5,637,40, colors[WHITE]);
		row_5 = row_5 + 42;
		row_5++;
	 }
	}
	
	int row_6 = 5;
	for (int i=0; i<l; i++)//Using for loop to print 6th row of road.
	{
	while (row_6 <= 840)
	 {
		DrawSquare(row_6,595,40, colors[WHITE]);
		row_6 = row_6 + 42;
		row_6++;
	 }
	}
	
	int row_7 = 5;
	for (int i=0; i<l; i++)//Using for loop to print 7th row of road.
	{
	while (row_7 <= 840)
	 {
		DrawSquare(row_7,553,40, colors[WHITE]);
		row_7 = row_7 + 42;
		row_7++;
	 }
	}
	
	int row_8 = 5;
	for (int i=0; i<l; i++)//Using for loop to print 8th row of road.
	{
	while (row_8 <= 840)
	 {
		DrawSquare(row_8,511,40, colors[WHITE]);
		row_8 = row_8 + 42;
		row_8++;
	 }
	}
	
	int row_9 = 5;
	for (int i=0; i<l; i++)//Using for loop to print 9th row of road.
	{
	while (row_9 <= 840)
	 {
		DrawSquare(row_9,469,40, colors[WHITE]);
		row_9 = row_9 + 42;
		row_9++;
	 }
	}
	
	int row_10 = 5;
	for (int i=0; i<l; i++)//Using for loop to print 10th row of road.
	{
	while (row_10 <= 840)
	 {
		DrawSquare(row_10,427,40, colors[WHITE]);
		row_10 = row_10 + 42;
		row_10++;
	 }
	}
	
	int row_11 = 5;
	for (int i=0; i<l; i++)//Using for loop to print 11th row of road.
	{
	while (row_11 <= 840)
	 {
		DrawSquare(row_11,385,40, colors[WHITE]);
		row_11 = row_11 + 42;
		row_11++;
	 }
	}
	
	int row_12 = 5;
	for (int i=0; i<l; i++)//Using for loop to print 12th row of road.
	{
	while (row_12 <= 840)
	 {
		DrawSquare(row_12,343,40, colors[WHITE]);
		row_12 = row_12 + 42;
		row_12++;
	 }
	}
	
	int row_13 = 5;
	for (int i=0; i<l; i++)//Using for loop to print 13th row of road.
	{
	while (row_13 <= 840)
	 {
		DrawSquare(row_13,301,40, colors[WHITE]);
		row_13 = row_13 + 42;
		row_13++;
	 }
	}
	
	int row_14 = 5;
	for (int i=0; i<l; i++)//Using for loop to print 14th row of road.
	{
	while (row_14 <= 840)  
	 {
		DrawSquare(row_14,259,40, colors[WHITE]);
		row_14 = row_14 + 42;
		row_14++;
	 }
	}
	
	int row_15 = 5;
	for (int i=0; i<l; i++)//Using for loop to print 15th row of road.
	{
	while (row_15 <= 840) 
	 {
		DrawSquare(row_15,217,40, colors[WHITE]);
		row_15 = row_15 + 42;
		row_15++;
	 }
	}
	
	int row_16 = 5;
	for (int i=0; i<l; i++)//Using for loop to print 16th row of road.
	{
	while (row_16 <= 840)
	 {
		DrawSquare(row_16,175,40, colors[WHITE]);
		row_16 = row_16 + 42;
		row_16++;
	 }
	}
	
	int row_17 = 5;
	for (int i=0; i<l; i++)//Using for loop to print 17th row of road.
	{
	while (row_17 <= 840)
	 {
		DrawSquare(row_17,133,40, colors[WHITE]);
		row_17 = row_17 + 42;
		row_17++;
	 }
	}
	
	int row_18 = 5;
	for (int i=0; i<l; i++)//Using for loop to print 18th row of road.
	{
	while (row_18 <= 840)
	 {
		DrawSquare(row_18,91,40, colors[WHITE]);
		row_18 = row_18 + 42;
		row_18++;
	 }
	}
	
	int row_19 = 5;
	for (int i=0; i<l; i++)//Using for loop to print 19th row of road.
	{
	while (row_19 <= 840)
	 {
		DrawSquare(row_19,49,40, colors[WHITE]);
		row_19 = row_19 + 42;
		row_19++;
	 }
	}
	
	int row_20 = 5;
	for (int i=0; i<l; i++)//Using for loop to print 20th row of road.
	{
	while (row_20 <= 840)
	 {
		DrawSquare(row_20,7,40, colors[WHITE]);
		row_20 = row_20 + 42;
		row_20++;
	 }
	}

        }



void Buildings_as_obstacle(){

//drawing buildings as obstacles
        DrawSquare(91,721,40, colors[INDIGO]);//3rd block from x axis and 3rd block from y axis.
	DrawSquare(134,721,40, colors[INDIGO]);//4th block from x axis and 3rd block from y axis.
	DrawSquare(177,721,40, colors[INDIGO]);//5th block from x axis and 3rd block from y axis.
	
	int block_10_to_20 = 392 , l = 600;
	for (int i=0; i<l; i++){
	while (block_10_to_20 <= 840){
	DrawSquare(block_10_to_20,721,40, colors[INDIGO]);//10-20 blocks from x axis and 3 blocks from y axis.
	block_10_to_20 += 42;
	block_10_to_20++;
	}}
	
	DrawSquare(306,679,40, colors[INDIGO]);//8th block from x axis and 4rd block from y axis.
	DrawSquare(306,637,40, colors[INDIGO]);//8th block from x axis and 5rd block from y axis.
	DrawSquare(306,595,40, colors[INDIGO]);//8th block from x axis and 6rd block from y axis.
	DrawSquare(306,553,40, colors[INDIGO]);//8th block from x axis and 7rd block from y axis.
	
	DrawSquare(91,553,40, colors[INDIGO]);//3rd block from x axis and 7th block from y axis.
	DrawSquare(134,553,40, colors[INDIGO]);//4th block from x axis and 7th block from y axis.
	
	DrawSquare(220,553,40, colors[INDIGO]);//6th block from x axis and 7th block from y axis.
	DrawSquare(263,553,40, colors[INDIGO]);//7th block from x axis and 7th block from y axis.
	
	DrawSquare(521,553,40, colors[INDIGO]);//13th block from x axis and 7th block from y axis.
	DrawSquare(564,553,40, colors[INDIGO]);//14th block from x axis and 7th block from y axis.
	DrawSquare(607,553,40, colors[INDIGO]);//15th block from x axis and 7th block from y axis.
	DrawSquare(650,553,40, colors[INDIGO]);//16th block from x axis and 7th block from y axis.
	
	DrawSquare(521,637,40, colors[INDIGO]);//13th block from x axis and 5th block from y axis.
	DrawSquare(521,595,40, colors[INDIGO]);//13th block from x axis and 6th block from y axis.
	DrawSquare(521,511,40, colors[INDIGO]);//13th block from x axis and 8th block from y axis.
	DrawSquare(521,469,40, colors[INDIGO]);//13th block from x axis and 9th block from y axis.
	DrawSquare(521,427,40, colors[INDIGO]);//13th block from x axis and 10th block from y axis.
	
	DrawSquare(134,511,40, colors[INDIGO]);//4th block from x axis and 8th block from y axis.
	DrawSquare(392,511,40, colors[INDIGO]);//10th block from x axis and 7th block from y axis.
	
	DrawSquare(779,637,40, colors[INDIGO]);//19th block from x axis and 5th block from y axis.
	DrawSquare(779,595,40, colors[INDIGO]);//19th block from x axis and 6th block from y axis.
	DrawSquare(779,553,40, colors[INDIGO]);//19th block from x axis and 7th block from y axis.
	DrawSquare(779,511,40, colors[INDIGO]);//19th block from x axis and 8th block from y axis.
	DrawSquare(779,469,40, colors[INDIGO]);//19th block from x axis and 9th block from y axis.
	
	DrawSquare(134,469,40, colors[INDIGO]);//4th block from x axis and 9th block from y axis.
	
	DrawSquare(220,343,40, colors[INDIGO]);//6th block from x axis and 12th block from y axis.
	DrawSquare(220,301,40, colors[INDIGO]);//6th block from x axis and 13th block from y axis.
	DrawSquare(220,259,40, colors[INDIGO]);//6th block from x axis and 14th block from y axis.
	DrawSquare(220,217,40, colors[INDIGO]);//6th block from x axis and 15th block from y axis.
	DrawSquare(220,175,40, colors[INDIGO]);//6th block from x axis and 16th block from y axis.
	DrawSquare(220,133,40, colors[INDIGO]);//6th block from x axis and 17th block from y axis.
	DrawSquare(220,91,40, colors[INDIGO]); //6th block from x axis and 18th block from y axis.
	
	DrawSquare(91,259,40, colors[INDIGO]);//3rd block from x axis and 14th block from y axis.
	DrawSquare(134,259,40, colors[INDIGO]);//4th block from x axis and 14th block from y axis.
	DrawSquare(91,217,40, colors[INDIGO]);//3rd block from x axis and 15th block from y axis.
	DrawSquare(134,217,40, colors[INDIGO]);//4th block from x axis and 15th block from y axis.
	DrawSquare(91,175,40, colors[INDIGO]);//3rd block from x axis and 16th block from y axis.
	DrawSquare(134,175,40, colors[INDIGO]);//3th block from x axis and 16th block from y axis.
	
	
	DrawSquare(736,49,40, colors[INDIGO]);//18th block from x axis and 19th block from y axis.
	DrawSquare(779,49,40, colors[INDIGO]);//19th block from x axis and 19th block from y axis.
        
       DrawSquare(392,91,40, colors[INDIGO]);//10th block from x axis and 18th block from y axis.
       DrawSquare(392,49,40, colors[INDIGO]);//10th block from x axis and 19th block from y axis.
       DrawSquare(392,7,40, colors[INDIGO]); //10th block from x axis and 20th block from y axis.
       
       DrawSquare(306,217,40, colors[INDIGO]);//8th block from x axis and 15th block from y axis.
       DrawSquare(349,217,40, colors[INDIGO]);//9th block from x axis and 15th block from y axis
       DrawSquare(392,217,40, colors[INDIGO]);//10th block from x axis and 15th block from y axis
       DrawSquare(435,217,40, colors[INDIGO]);//11h block from x axis and 15th block from y axis
       DrawSquare(478,217,40, colors[INDIGO]);//12th block from x axis and 15th block from y axis
       
       DrawSquare(478,259,40, colors[INDIGO]);//12th block from x axis and 14th block from y axis
       DrawSquare(478,301,40, colors[INDIGO]);//12th block from x axis and 14th block from y axis
       
       DrawSquare(607,259,40, colors[INDIGO]);//15th block from x axis and 14th block from y axis
       DrawSquare(650,259,40, colors[INDIGO]);//16th block from x axis and 14th block from y axis
       DrawSquare(693,259,40, colors[INDIGO]);//17th block from x axis and 14th block from y axis
       DrawSquare(736,259,40, colors[INDIGO]);//18th block from x axis and 14th block from y axis
       DrawSquare(779,259,40, colors[INDIGO]);//19th block from x axis and 14th block from y axis
       DrawSquare(822,259,40, colors[INDIGO]);//20th block from x axis and 14th block from y axis
       
       DrawSquare(607,217,40, colors[INDIGO]);//15th block from x axis and 15th block from y axis
       DrawSquare(607,175,40, colors[INDIGO]);//15th block from x axis and 16th block from y axis
       DrawSquare(607,133,40, colors[INDIGO]);//15th block from x axis and 17th block from y axis
       
       DrawSquare(392,427,40, colors[INDIGO]);//10th block from x axis and 10th block from y axis
       DrawSquare(392,385,40, colors[INDIGO]);//10th block from x axis and 11th block from y axis
       DrawSquare(349,385,40, colors[INDIGO]);//9th block from x axis and 11th block from y axis
       DrawSquare(306,385,40, colors[INDIGO]);//8th block from x axis and 11th block from y axis
       }



void boxes_as_obstacle(){

//drawing boxes as obstacle using drawsquare function.
       DrawSquare(139,683,30, colors[KHAKI]);
       DrawSquare(183,221,30, colors[KHAKI]);
       DrawSquare(699,178,30, colors[KHAKI]);
       DrawSquare(741,557,30, colors[KHAKI]);
       DrawSquare(138,389,30, colors[KHAKI]);
       }


void car_not_touching_boxes(){

//restricting car to collide with boxes 
       if(xI >= 132 && xI <= 176 && yI >= 680 && yI <= 720 ){
	xI -= 43;
	yI += 43;}
	
	if(xI >= 132 && xI <= 176 && yI >= 382 && yI <= 426 ){
	xI -= 43;
	yI += 43;}
	
	if(xI >= 176 && xI <= 218 && yI >= 212 && yI <= 262 ){
	xI -= 43;
	yI += 43;}
	
	if(xI >= 734 && xI <= 776 && yI >= 550 && yI <= 594 ){
	xI -= 43;
	yI += 43;}
	
	if(xI >= 734 && xI <= 776 && yI >= 550 && yI <= 594 ){
	xI -= 43;
	yI += 43;}
	}


void trees_as_obstacle(){

//drawing trees as obstacles.
       DrawCircle(455,790,15,colors[DARK_GREEN]);
       DrawLine( 455 , 790 ,  455 , 765 , 10 , colors[BROWN]);
       
       DrawCircle(285,620,15,colors[DARK_GREEN]);
       DrawLine(285 , 620 ,  285 , 596 , 10 , colors[BROWN]);
       
       DrawCircle(410,285,15,colors[DARK_GREEN]);
       DrawLine(410 , 285 ,  410 , 260 , 10 , colors[BROWN]);
       
       DrawCircle(755,327,15,colors[DARK_GREEN]);
       DrawLine(755 , 327 ,  755 , 301 , 10 , colors[BROWN]);
       
       DrawCircle(500,579,15,colors[DARK_GREEN]);
       DrawLine(500 , 579 ,  500 , 553 , 10 , colors[BROWN]);
       }
       
       
void car_not_touching_trees(){

//restricting car to collide with trees
        if(xI >= 435 && xI <= 475 && yI >= 760 && yI <= 804 ){
	xI -= 43;
	yI += 43;}
	
	if(xI >= 262 && xI <= 302 && yI >= 596 && yI <= 635 ){
	xI -= 43;
	yI += 43;}
	
	if(xI >= 475 && xI <= 519 && yI >= 548 && yI <= 595 ){
	xI -= 43;
	yI += 43;}
	
	if(xI >= 390 && xI <= 432 && yI >= 548 && yI <= 595 ){
	xI -= 43;
	yI += 43;}
	
	if(xI >= 736 && xI <= 780 && yI >= 302 && yI <= 340 ){
	xI -= 43;
	yI += 43;}
	}
       
       

void drawing_border_on_grid(){
// drawing border around grid.

        DrawLine(0, 3, 0, 847, 7, colors[RED]);
	DrawLine(0, 850, 869, 850, 7, colors[RED]);
	DrawLine(868, 3, 868, 847, 7, colors[RED]);
	}

       
void car_staying_in_the_grid(){


//using if else statement so the car don't move out of the grid.
	if(xI <= 5){
	xI = 7;
	}
	if(yI <=7){
	yI = 10;
	}
	
	if(xI >= 825){
	xI = 825;
	}
	if(yI >= 808){
	yI = 808;
	}
	
	}



void border_along_buildings(){

//making border along the buildings.
        DrawLine(92, 760, 216, 760, 4, colors[RED]);
	DrawLine(92, 720, 92, 760, 4, colors[RED]);
	DrawLine(92, 720, 216, 720, 4, colors[RED]);
	DrawLine(216, 720, 216, 760, 4, colors[RED]);
	
	
	DrawLine(392, 760, 863, 760, 4, colors[RED]);
	DrawLine(392, 720, 392, 760, 4, colors[RED]);
	DrawLine(392, 720, 863, 720, 4, colors[RED]);
	DrawLine(863, 720, 863, 760, 4, colors[RED]);
	
	DrawLine(306, 718, 346, 718, 4, colors[RED]);
	DrawLine(346, 551, 346, 718, 4, colors[RED]);
	DrawLine(303, 594, 303, 718, 4, colors[RED]);
	DrawLine(219, 551, 346, 551, 4, colors[RED]);
	DrawLine(219, 551, 219, 594, 4, colors[RED]);
	DrawLine(219, 594, 303, 594, 4, colors[RED]);
	
	DrawLine(520, 426, 520, 678, 4, colors[RED]);
	DrawLine(520, 678, 563, 678, 4, colors[RED]);
	DrawLine(563, 426, 563, 550, 4, colors[RED]);
	DrawLine(563, 590, 563, 680, 4, colors[RED]);
	DrawLine(520, 426, 563, 426, 4, colors[RED]);
	DrawLine(563, 552, 689, 552, 4, colors[RED]);
	DrawLine(691, 552, 691, 593, 4, colors[RED]);
	DrawLine(563, 593, 691, 593, 4, colors[RED]);
	
	
	DrawLine(779, 469, 779, 676, 4, colors[RED]);
	DrawLine(779, 676, 819, 676, 4, colors[RED]);
	DrawLine(819, 469, 819, 676, 4, colors[RED]);
	DrawLine(779, 469, 819, 469, 4, colors[RED]);
	
	DrawLine(92, 552, 130, 552, 4, colors[RED]);
	DrawLine(174, 552, 174, 592, 4, colors[RED]);
	DrawLine(92, 592, 174, 592, 4, colors[RED]);
	DrawLine(92, 552, 92, 592, 4, colors[RED]);
	DrawLine(132, 468, 132, 556, 4, colors[RED]);
	DrawLine(132, 468, 174, 468, 4, colors[RED]);
	DrawLine(174, 468, 174, 556, 4, colors[RED]);

	
	DrawLine(390, 510, 432, 510, 4, colors[RED]);
	DrawLine(432, 510, 432, 550, 4, colors[RED]);
	DrawLine(390, 550, 432, 550, 4, colors[RED]);
	DrawLine(390, 510, 390, 550, 4, colors[RED]);
	
	DrawLine(90, 174, 90, 298, 4, colors[RED]);
	DrawLine(90, 298, 174, 298, 4, colors[RED]);
	DrawLine(174, 174, 174, 298, 4, colors[RED]);
	DrawLine(90, 174, 174, 174, 4, colors[RED]);
	
	DrawLine(218, 90, 218, 382, 4, colors[RED]);
	DrawLine(218, 382, 260, 382, 4, colors[RED]);
	DrawLine(260, 90, 260, 382, 4, colors[RED]);
	DrawLine(218, 90, 260, 90, 4, colors[RED]);
	
	DrawLine(390, 7, 390, 130, 4, colors[RED]);
	DrawLine(390, 130, 433, 130, 4, colors[RED]);
	DrawLine(433, 7, 433, 130, 4, colors[RED]);
	DrawLine(390, 7, 433, 7, 4, colors[RED]);
	
	DrawLine(736, 49, 818, 49, 4, colors[RED]);
	DrawLine(818, 49, 818, 88, 4, colors[RED]);
	DrawLine(736, 88, 818, 88, 4, colors[RED]);
	DrawLine(736, 49, 736, 88, 4, colors[RED]);
	
	DrawLine(606, 300, 866, 300, 4, colors[RED]);
	DrawLine(866, 260, 866, 300, 4, colors[RED]);
	DrawLine(646, 260, 866, 260, 4, colors[RED]);
	DrawLine(606, 260, 606, 300, 4, colors[RED]);
	DrawLine(606, 132, 606, 256, 4, colors[RED]);
	DrawLine(606, 132, 646, 132, 4, colors[RED]);
	DrawLine(646, 132, 646, 256, 4, colors[RED]);
	
	DrawLine(306, 216, 518, 216, 4, colors[RED]);
	DrawLine(518, 216, 518, 256, 4, colors[RED]);
	DrawLine(306, 256, 476, 256, 4, colors[RED]);
	DrawLine(306, 216, 306, 256, 4, colors[RED]);
	DrawLine(476, 256, 476, 340, 4, colors[RED]);
	DrawLine(476, 340, 518, 340, 4, colors[RED]);
	DrawLine(518, 256, 518, 340, 4, colors[RED]);
	
	DrawLine(306, 425, 432, 425, 4, colors[RED]);
	DrawLine(432, 383, 432, 425, 4, colors[RED]);
	DrawLine(306, 383, 432, 383, 4, colors[RED]);
	DrawLine(306, 383, 306, 425, 4, colors[RED]);
	
	DrawLine(390, 424, 390, 466, 4, colors[RED]);
	DrawLine(390, 466, 432, 466, 4, colors[RED]);
	DrawLine(432, 424, 432, 466, 4, colors[RED]);
	
	
	
	
	
	

	
	
	}




void car_not_touching_buildings(){

//using if statement so that car does not collide with buildings.	
	if(xI >= 92 && xI <= 216 && yI >= 720 && yI <= 761 ){
	xI -= 43;
	yI += 43;} 
	
	if(xI >= 392 && xI <= 863 && yI >= 720 && yI <= 761 ){
	xI -= 43;
	yI += 43;} 
	
	
	if(xI >= 303 && xI <= 346 && yI >= 550 && yI <= 718 ){
	xI -= 43;
	yI += 43;} 
	
	
	if(xI >= 219 && xI <= 346 && yI >= 550 && yI <= 594 ){
	xI -= 43;
	yI += 43;}
	
	
	if(xI >= 520 && xI <= 563 && yI >= 426 && yI <= 678 ){
	xI -= 43;
	yI += 43;} 
	
	if(xI >= 563 && xI <= 691 && yI >= 552 && yI <= 593 ){
	xI -= 43;
	yI += 43;}
	
	
	if(xI >= 779 && xI <= 819 && yI >= 469 && yI <= 676 ){
	xI -= 43;
	yI += 43;}
	
	
	if(xI >= 92 && xI <= 174 && yI >= 552 && yI <= 592 ){
	xI -= 43;
	yI += 43;}
	
	if(xI >= 132 && xI <= 174 && yI >= 468 && yI <= 556 ){
	xI -= 43;
	yI += 43;}

	if(xI >= 390 && xI <= 432 && yI >= 510 && yI <= 550 ){
	xI -= 43;
	yI += 43;}
	
	if(xI >= 90 && xI <= 174 && yI >= 174 && yI <= 298 ){
	xI -= 43;
	yI += 43;}
	
	if(xI >= 218 && xI <= 260 && yI >= 90 && yI <= 382 ){
	xI -= 43;
	yI += 43;}
	
	if(xI >= 390 && xI <= 433 && yI >= 7 && yI <= 130 ){
	xI -= 43;
	yI += 43;}
	
	if(xI >= 736 && xI <= 818 && yI >= 49 && yI <= 88 ){
	xI -= 43;
	yI += 43;}
	
	if(xI >= 606 && xI <= 866 && yI >= 260 && yI <= 300 ){
	xI -= 43;
	yI += 43;}
	
	if(xI >= 606 && xI <= 646 && yI >= 132 && yI <= 256 ){
	xI -= 43;
	yI += 43;}
	
	if(xI >= 305 && xI <= 518 && yI >= 216 && yI <= 256 ){
	xI -= 43;
	yI += 43;}
	
	if(xI >= 476 && xI <= 518 && yI >= 256 && yI <= 340 ){
	xI -= 43;
	yI += 43;}
	
	if(xI >= 306 && xI <= 432 && yI >= 383 && yI <= 425 ){
	xI -= 43;
	yI += 43;}
	
	if(xI >= 692 && xI <= 734 && yI >= 172 && yI <= 214 ){
	xI -= 43;
	yI += 43;}
	
	}




       bool passenger_1 = true;
       
void Drawing_passenger_1(){

       // Drawing passenger number 1.
       DrawCircle(585,793,7,colors[BLACK]);
       DrawLine(585 , 793 ,  585 , 765 , 3 , colors[BLACK]);



       //using if statement so that car does not collide with passenger # 1. 
       if(xI >= 562 && xI <= 604 && yI >= 762 && yI <= 804 ){
	xI -= 43;
	yI += 43;}
	
}

bool drop_1 = false;
void dropping_passenger_1(){
// Drawing passenger number 1.
	DrawCircle(634, 615, 10, colors[GREEN]);
	
	glutPostRedisplay();
	}


bool passenger_2 = true;
void Drawing_passenger_2(){

       // Drawing passenger number 3.
       DrawCircle(369,501,7,colors[BLACK]);
       DrawLine(369 , 501 ,  369 , 471 , 3 , colors[BLACK]);


      //using if statement so that car does not collide with passenger # 2.
      if(xI >= 346 && xI <= 390 && yI >= 468 && yI <= 512 ){
	xI -= 43;
	yI += 43;
	}
	}

	
bool drop_2 = false;
void dropping_passenger_2(){
	DrawCircle(588, 615, 10, colors[GREEN]);

	glutPostRedisplay();
	}	
       
       
       
       
       
       
       
       
       
       
bool passenger_3 = true;
void Drawing_passenger_3(){

       // Drawing passenger number 3.
       DrawCircle(671,335,7,colors[BLACK]);
       DrawLine(671 , 335 ,  671 , 305 , 3 , colors[BLACK]);


      //using if statement so that car does not collide with passenger # 3.
      if(xI >= 648 && xI <= 688 && yI >= 292 && yI <= 340 ){
	xI -= 43;
	yI += 43;}
	}

	
bool drop_3 = false;
void dropping_passenger_3(){
	DrawCircle(664, 615, 10, colors[GREEN]);

	glutPostRedisplay();
	}	
	
	
	
bool passenger_4 = true;
void Drawing_passenger_4(){

       // Drawing passenger number 4.
       DrawCircle(715,246,7,colors[BLACK]);
       DrawLine(715 , 246 ,  715 , 220 , 3 , colors[BLACK]);

      //using if statement so that car does not collide with passenger # 4.
      if(xI >= 692 && xI <= 732 && yI >= 212 && yI <= 260 ){
	xI -= 43;
	yI += 43;}
	}

	
bool drop_4 = false;
void dropping_passenger_4(){
	DrawCircle(840, 820, 10, colors[GREEN]);

	glutPostRedisplay();
	}		
       

       
bool passenger_5 = true;
void Drawing_passenger_5(){

       // Drawing passenger number 5.
       DrawCircle(157,163,7,colors[BLACK]);
       DrawLine(157 , 163 ,  157 , 133 , 3 , colors[BLACK]);
       

      //using if statement so that car does not collide with passenger # 5.
      if(xI >= 132 && xI <= 172 && yI >= 130 && yI <= 168 ){
	xI -= 43;
	yI += 43;}
	}

	
bool drop_5 = false;
void dropping_passenger_5(){
	DrawCircle(675, 115, 10, colors[GREEN]);
	

	glutPostRedisplay();
	}	

       
void main_menu(){

//making function for menu.
       glClearColor(0/*Red Component*/, 0,	//148.0/255/*Green Component*/,
			0.0/*Blue Component*/, 0 /*Alpha component*/); // Red==Green==Blue==1 --> White Colour
	glClear (GL_COLOR_BUFFER_BIT); //Update the colors
	
	DrawString(400,800,"RUSH HOUR GAME",colors[WHITE]);
	DrawString(365,750,"Welcome to the Game Menu",colors[WHITE]);
	DrawString(5,650,"Name : Munam Mustafa",colors[WHITE]);
	DrawString(5,615,"Roll no : 21i-0460",colors[WHITE]);
	DrawString(5,580,"Section : BSCS-D",colors[WHITE]);
	
	DrawString(250,450,"IF YOU WANT TO PLAY THE GAME PRESS 'Y'",colors[WHITE]);
	
	
	
	
	glutSwapBuffers();
       }
       
       
/*
 * Main Canvas drawing function.
 * */

void GameDisplay()/**/{
	// set the background color using function glClearColor.
	// to change the background play with the red, green and blue values below.
	// Note that r, g and b values must be in the range [0,1] where 0 means dim rid and 1 means pure red and so on.

	glClearColor(0/*Red Component*/, 0,	//148.0/255/*Green Component*/,
			0.0/*Blue Component*/, 0 /*Alpha component*/); // Red==Green==Blue==1 --> White Colour
	glClear (GL_COLOR_BUFFER_BIT); //Update the colors
	//Red Square
	//DrawSquare(0, 800, 40, colors[WHITE]);
	//DrawSquare(42,800,40, colors[WHITE]); 
	
	//making roads with the help of for loop using DrawSquare function.
	
	
	//Green Square
	//DrawSquare( 250 , 250 ,20,colors[GREEN]); 
	
	//Display Score
	DrawString(900, 800, "Score=0", colors[MISTY_ROSE]);
	
	// Trianlge Vertices v1(300,50) , v2(500,50) , v3(400,250)
	//DrawTriangle( 300, 450 , 340, 450 , 320 , 490, colors[MISTY_ROSE] ); 
	

/*
	//DrawLine(int x1, int y1, int x2, int y2, int lwidth, float *color)
	DrawLine( 550 , 50 ,  550 , 480 , 10 , colors[MISTY_ROSE] );	
	
	DrawCircle(50,670,10,colors[RED]);
	DrawCircle(70,670,10,colors[RED]);
	DrawCircle(90,670,10,colors[RED]);
	DrawRoundRect(500,200,50,100,colors[DARK_SEA_GREEN],70);
	DrawRoundRect(100,200,100,50,colors[DARK_OLIVE_GREEN],20);	
	DrawRoundRect(100,100,50,100,colors[DARK_OLIVE_GREEN],30);
//	DrawRoundRect(200,100,100,50,colors[LIME_GREEN],40);
//	DrawRoundRect(350,100,100,50,colors[LIME_GREEN],20);
	*/
	
	Drawing_roads();
	
	Buildings_as_obstacle();
	
	boxes_as_obstacle();
	
	car_not_touching_boxes();
	
	trees_as_obstacle();
	
	car_not_touching_trees();
	
	drawing_border_on_grid();
	
	car_staying_in_the_grid();
	
	border_along_buildings();
	
	car_not_touching_buildings();
	
	if (passenger_1 == true)
	Drawing_passenger_1();
	
	if (passenger_1 == false && drop_1 == true)
	dropping_passenger_1();
	
	if (passenger_2 == true)
	Drawing_passenger_2();
	
	if (passenger_2 == false && drop_2 == true)
	dropping_passenger_2();
	
	if (passenger_3 == true)
	Drawing_passenger_3();
	
	if (passenger_3 == false && drop_3 == true)
	dropping_passenger_3();
	
	if (passenger_4 == true)
	Drawing_passenger_4();
	
	if (passenger_4 == false && drop_4 == true)
	dropping_passenger_4();
	
	if (passenger_5 == true)
	Drawing_passenger_5();
	
	if (passenger_5 == false && drop_5 == true)
	dropping_passenger_5();

	drawCar();
	
	glutSwapBuffers(); // do not modify this line..

}



/*This function is called (automatically) whenever any non-printable key (such as up-arrow, down-arraw)
 * is pressed from the keyboard
 *
 * You will have to add the necessary code here when the arrow keys are pressed or any other key is pressed...
 *
 * This function has three argument variable key contains the ASCII of the key pressed, while x and y tells the
 * program coordinates of mouse pointer when key was pressed.
 *
 * */
 
  
 
void NonPrintableKeys(int key, int x, int y) {
	if (key == GLUT_KEY_LEFT /*GLUT_KEY_LEFT is constant and contains ASCII for left arrow key*/) {
		// what to do when left key is pressed...
		xI -= 42;
		xI--;

	} else if (key == GLUT_KEY_RIGHT /*GLUT_KEY_RIGHT is constant and contains ASCII for right arrow key*/) {
		xI += 42;
		xI++;
		
	} else if (key == GLUT_KEY_UP/*GLUT_KEY_UP is constant and contains ASCII for up arrow key*/) {
		yI += 42;
	}

	else if (key == GLUT_KEY_DOWN/*GLUT_KEY_DOWN is constant and contains ASCII for down arrow key*/) {
		yI -= 42;
	}

	/* This function calls the Display function to redo the drawing. Whenever you need to redraw just call
	 * this function*/

	glutPostRedisplay();

}
/*This function is called (automatically) whenever any printable key (such as x,b, enter, etc.)
 * is pressed from the keyboard
 * This function has three argument variable key contains the ASCII of the key pressed, while x and y tells the
 * program coordinates of mouse pointer when key was pressed.
 * */
void PrintableKeys(unsigned char key, int x, int y) {
	if (key == 27/* Escape key ASCII*/) {
	exit(1);
	}
	
	//using if condition to pick up the passenger # 1.
	if (key == 32 && xI >= 518 && xI <= 562 && yI >= 762 && yI <= 804 ){//piking first passenger from left side
	passenger_1 = false;
	drop_1 = true;
	}
		
	if (key == 32 && xI >= 562 && xI <= 604 && yI >= 800 && yI <= 844 ){//piking first passenger from right side
	passenger_1 = false;
	drop_1 = true;
	}
	
	if (key == 32 && xI >= 604 && xI <= 646 && yI >= 762 && yI <= 804 ){//piking first passenger from right side
	passenger_1 = false;
	drop_1 = true;
	}
	
	//using if condition to drop the passenger.
	if (key == 32 && xI >= 606 && xI <= 648 && yI >= 594 && yI <= 634 ){
		passenger_1 = false;
		drop_1 = false;
		}
		
	
	
	
	
	
	
	//using if condition to pick up the passenger # 2.
	
	if (key == 32 && xI >= 306 && xI <= 346 && yI >= 468 && yI <= 512 ){//piking second passenger from right side
	passenger_2 = false;
	drop_2 = true;
	}		
	
	
	if (key == 32 && xI >= 346 && xI <= 388 && yI >= 512 && yI <= 542 ){//piking second passenger from left side
	passenger_2 = false;
	drop_2 = true;
	}		
	
	if (key == 32 && xI >= 346 && xI <= 388 && yI >= 430 && yI <= 472 ){//piking secnd passenger from up side
	passenger_2 = false;
	drop_2 = true;
	}		
	
	
	if (key == 32 && xI >= 388 && xI <= 432 && yI >= 468 && yI <= 518 ){//piking secnd passenger from down side
	passenger_2 = false;
	drop_2 = true;
	}		
	
	//using if condition drop up the passenger.
	if (key == 32 && xI >= 556 && xI <= 606 && yI >= 594 && yI <= 634 ){
		passenger_2 = false;
		drop_2 = false;

	}
	
	
	
	
	
	
	//using if condition to pick up the passenger # 3.
	
	if (key == 32 && xI >= 602 && xI <= 648 && yI >= 292 && yI <= 340 ){//piking second passenger from right side
	passenger_3 = false;
	drop_3 = true;
	}		
	
	if (key == 32 && xI >= 648 && xI <= 692 && yI >= 340 && yI <= 380 ){//piking second passenger from left side
	passenger_3 = false;
	drop_3 = true;
	}		
	
	if (key == 32 && xI >= 692 && xI <= 736 && yI >= 300 && yI <= 340 ){//piking second passenger from up side
	passenger_3 = false;
	drop_3 = true;
	}		
	
	//using if condition to drop the passenger.
	if (key == 32 && xI >= 644 && xI <= 688 && yI >= 592 && yI <= 632 ){//droping secnd passenger from right side
		passenger_3 = false;
		drop_3 = false;

	}
	
	
	
	
	
	
	
	//using if condition to pick up the passenger # 4.
	
	if (key == 32 && xI >= 652 && xI <= 692 && yI >= 212 && yI <= 260 ){//piking second passenger from right side
	passenger_4 = false;
	drop_4 = true;
	}		
	
	if (key == 32 && xI >= 738 && xI <= 774 && yI >= 212 && yI <= 260 ){//piking second passenger from left side
	passenger_4 = false;
	drop_4 = true;
	}
	
	//using if condition to drop the passenger.
	if (key == 32 && xI >= 820 && xI <= 862 && yI >= 800 && yI <= 840 ){
		passenger_4 = false;
		drop_4 = false;

	}		
	
	
	
	
	//using if condition to pick up the passenger # 5.
	
	if (key == 32 && xI >= 176 && xI <= 218 && yI >= 130 && yI <= 168 ){//piking second passenger from right side
	passenger_5 = false;
	drop_5 = true;
	}		
	
	if (key == 32 && xI >= 132 && xI <= 176 && yI >= 92 && yI <= 130 ){//piking second passenger from left side
	passenger_5 = false;
	drop_5 = true;
	}		
	
	if (key == 32 && xI >= 92 && xI <= 132 && yI >= 130 && yI <= 176 ){//piking second passenger from up side
	passenger_5 = false;
	drop_5 = true;
	}		
	
	//using if condition to drop the passenger.
	if (key == 32 && xI >= 648 && xI <= 692 && yI >= 92 && yI <= 134 ){
		passenger_5 = false;
		drop_5 = false;
		}


	
	
	if (key == 'Y' || key == 'y') {
	glutDisplayFunc(GameDisplay);
	}
	
	glutPostRedisplay();
}



/*
 * This function is called after every 1000.0/FPS milliseconds
 * (FPS is defined on in the beginning).
 * You can use this function to animate objects and control the
 * speed of different moving objects by varying the constant FPS.
 *
 * */
void Timer(int m) {

	// implement your functionality here
	//moveCar();

	// once again we tell the library to call our Timer function after next 1000/FPS
	//// This function tells the library to call our Timer function after 1000.0/FPS milliseconds...
	glutTimerFunc(100, Timer, 0);

}

/*This function is called (automatically) whenever your mouse moves witin inside the game window
 *
 * You will have to add the necessary code here for finding the direction of shooting
 *
 * This function has two arguments: x & y that tells the coordinate of current position of move mouse
 *
 * */
void MousePressedAndMoved(int x, int y) {
	//cout << x << " " << y << endl;
	//glutPostRedisplay();
}
void MouseMoved(int x, int y) {
	//cout << x << " " << y << endl;
	//glutPostRedisplay();
}

/*This function is called (automatically) whenever your mouse button is clicked witin inside the game window
 *
 * You will have to add the necessary code here for shooting, etc.
 *
 * This function has four arguments: button (Left, Middle or Right), state (button is pressed or released),
 * x & y that tells the coordinate of current position of move mouse
 *
 * */
void MouseClicked(int button, int state, int x, int y) {

	//if (button == GLUT_LEFT_BUTTON) // dealing only with left button
	//		{
	//	cout << GLUT_DOWN << " " << GLUT_UP << endl;

	//} else if (button == GLUT_RIGHT_BUTTON) // dealing with right button
	//		{
	//		cout<<"Right Button Pressed"<<endl;

	//}
	//glutPostRedisplay();
}







/*
void write(int choice){
         
         string name;
         cout << "Enter your Name : ";
         cin  << name;
         
         fstream score;
         
         score.open("high_score_file.txt", ios :: out | ios :: app);
         if (score){
         score << name << endl;
         }
         score.close
         }
         
void read(string high_score_array){
         string display;
         ifstream score;
         
         score.open("high_score_file.txt", ios :: in);
         if (score.is_open()){
         for(int i=0 ; i < 10 ; i++){
         getline(score , display);
         if (display == ""){
         cout << "you are first person playing " << endl;
         }
         }
         else{
         high_score_array[i] = display;
         }
         }
         
         for(int i=0 ; i < 10 ; i++){
         cout << (i + 1) << " " << high_score_array[i] << endl;
         }
         }



*/


/*
 * our gateway main function
 * */
int main(int argc, char*argv[]) {

	int width = 1025, height = 860; // i have set my window size to be 800 x 600
	/*int choice ;
	string high_score_array[10]; 
	
	cout << "Press 1 to write scores : ";
	cout << "Press 2 to read previous score : ";
	cin  >> choice;
	
	switch(choice){
	
	case 1:
	write(choice);
	
	case 2: 
	read(high_score_array);*/
	
	InitRandomizer(); // seed the random number generator...
	glutInit(&argc, argv); // initialize the graphics library...
	glutInitDisplayMode(GLUT_DOUBLE | GLUT_RGBA); // we will be using color display mode
	glutInitWindowPosition(50, 50); // set the initial position of our window
	glutInitWindowSize(width, height); // set the size of our window
	glutCreateWindow("Rush Hour by MUNAM MUSTAFA AHMED KHAN (21i-0460)"); // set the title of our game window
	SetCanvasSize(width, height); // set the number of pixels...

	// Register your functions to the library,
	// you are telling the library names of function to call for different tasks.
	//glutDisplayFunc(display); // tell library which function to call for drawing Canvas.

	glutDisplayFunc(main_menu); // tell library which function to call for drawing Canvas.
	glutSpecialFunc(NonPrintableKeys); // tell library which function to call for non-printable ASCII characters
	glutKeyboardFunc(PrintableKeys); // tell library which function to call for printable ASCII characters
	// This function tells the library to call our Timer function after 1000.0/FPS milliseconds...
	glutTimerFunc(1000.0, Timer, 0);

	glutMouseFunc(MouseClicked);
	glutPassiveMotionFunc(MouseMoved); // Mouse
	glutMotionFunc(MousePressedAndMoved); // Mouse

	// now handle the control to library and it will call our registered functions when
	// it deems necessary...
	glutMainLoop();
	return 1;
}
#endif /* RushHour_CPP_ */
